# CVE-2023-46747 - Big-IP RCE (Unauthenticated)


This is a Python3 script to exploit the unauthenticated remote code execution vulnerability (CVE-2023-46747) in **F5 BIG-IP** appliances via the TMUI interface. Basically, if this vuln hits, you get a shell *without credentials*.

Built with threading, file input support, proxy handling, optional shell access, and can check for vulnerable targets in bulk. Made for security researchers, pentesters, and red teamers who need fast & dirty automation.

## 💥 What it does

* Checks for unauthenticated access to `/tmui/login.jsp`
* Creates a new user via a forged chunked request
* Resets the initial password to enable login
* Fetches a token via the MGMT API
* Launches bash commands or an interactive shell

## ⚙️ Usage

```
python3 bigrce.py -u https://<target> --check
python3 bigrce.py -u https://<target> --shell
python3 bigrce.py -f targets.txt -t 20 --check
python3 bigrce.py -f targets.txt --shell --proxy http://127.0.0.1:8080
```

## 📌 Options

* `-u <url>`: Single target mode
* `-f <file>`: File of targets (one per line)
* `-t <threads>`: Number of threads (default: 5)
* `--check`: Just check if target is vulnerable
* `--shell`: Launch interactive RCE shell
* `-p <proxy>`: Route traffic through Burp/ZAP

## 🛠️ Dependencies

* Python 3.6+
* `requests`
* `colorama` (optional, for colored output)

Install them via pip if needed:

```bash
pip3 install requests colorama
```

## 📁 targets.txt format

```
https://192.168.1.1
192.168.1.2
bigip.company.internal
```

It’ll auto-fix HTTPs if missing.

## 🚧 Notes

* Use with caution. Make sure you have permission.
* Tested against vulnerable F5 BIG-IP v16.x.x
* Default timeout is 2–5 seconds to avoid overloading targets

## 🧙‍♂️ Author

By [cediegreyhat](https://github.com/cediegreyhat) — this repo is inspired by real-world usage during assessments. Modify and expand as you see fit.

---

Stay safe. Hack responsibly. 🐉

Feel free to open PRs if you want to improve this tool!
